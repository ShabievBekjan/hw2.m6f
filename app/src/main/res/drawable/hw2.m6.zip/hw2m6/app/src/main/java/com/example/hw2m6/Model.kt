package com.example.hw2m6

data class Model(
    val image:Int,
    var select:Boolean
):java.io.Serializable
